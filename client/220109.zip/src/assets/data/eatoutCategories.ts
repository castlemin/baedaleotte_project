/* 일반 외식 음식점 카테고리 목록 */
export const eatoutCategories: string[] = [
  '한식',
  '일식',
  '중식',
  '양식',
  '세계음식',
  '카페',
  '주점',
];
