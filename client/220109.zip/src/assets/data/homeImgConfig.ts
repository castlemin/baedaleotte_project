export const HOME_IMG_CONFIG = {
  margin: '40px 0 auto',
  marginLeft: '40px',
  width: '100%',
};
