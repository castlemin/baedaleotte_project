import styled from 'styled-components';

export const LottieContainer = styled.div`
  height: fit-content;
  margin: 30px 0 auto;
`;
