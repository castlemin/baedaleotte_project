import styled from 'styled-components';

export const TitleContainer = styled.h1`
  text-align: center;
`;
